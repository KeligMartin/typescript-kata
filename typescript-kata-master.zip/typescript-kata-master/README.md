# Code Kata TypeScript Template

This is a typescript kata to learn basics.

To use it follow these steps.

### Step 1. Clone the repository

`git clone git@github.com:KeligMartin/typescript-kata.git`

### Step 2. Install the dependencies (I use yarn)

`npm install`

### Step 3. Run the tests

`npm run test`

module.exports = {
  preset: 'ts-jest',
  coveragePathIgnorePatterns: [
    "<rootDir>/src/food"
  ],
};

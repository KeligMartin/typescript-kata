export enum VehicleType {
  Car,
  Moto,
  Truck,
  Rocket
}

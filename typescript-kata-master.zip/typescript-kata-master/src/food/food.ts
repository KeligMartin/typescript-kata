export default class Food {

  name: string;

  constructor(name: string) {
    this.name = name;
  }

  isVegan(): boolean {
    return undefined;
  }
}
